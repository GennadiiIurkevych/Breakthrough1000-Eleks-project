Застосування технологій:

React.js
Next.js
Sass
JavaScript
CSS
HTML


# Google Auth
Створи в корні проекту файл `.env.local` за зразком `.env.example`, візьми значення ключей у власника гугл проєкту. Перезапусти проєкт з `npm run dev`