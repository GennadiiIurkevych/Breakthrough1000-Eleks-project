"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyApp)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ \"prop-types\");\n/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/material/styles */ \"@mui/material/styles\");\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material/CssBaseline */ \"@mui/material/CssBaseline\");\n/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var _src_theme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../src/theme */ \"./src/theme.js\");\n/* harmony import */ var _src_createEmotionCache__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../src/createEmotionCache */ \"./src/createEmotionCache.js\");\n/* harmony import */ var _src_contexts_UserContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../src/contexts/UserContext */ \"./src/contexts/UserContext/index.jsx\");\n\n\n\n\n\n\n\n\n\n\n// Client-side cache shared for the whole session\n// of the user in the browser.\nconst clientSideEmotionCache = (0,_src_createEmotionCache__WEBPACK_IMPORTED_MODULE_8__[\"default\"])();\nfunction MyApp(props) {\n    const { Component , emotionCache =clientSideEmotionCache , pageProps  } = props;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_contexts_UserContext__WEBPACK_IMPORTED_MODULE_9__.UserProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react__WEBPACK_IMPORTED_MODULE_6__.CacheProvider, {\n            value: emotionCache,\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"meta\", {\n                        name: \"viewport\",\n                        content: \"initial-scale=1, width=device-width\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\Gennadii\\\\breakthrough1000-eleks-project\\\\pages\\\\_app.js\",\n                        lineNumber: 24,\n                        columnNumber: 6\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\Gennadii\\\\breakthrough1000-eleks-project\\\\pages\\\\_app.js\",\n                    lineNumber: 23,\n                    columnNumber: 5\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__.ThemeProvider, {\n                    theme: _src_theme__WEBPACK_IMPORTED_MODULE_7__[\"default\"],\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_5___default()), {}, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Gennadii\\\\breakthrough1000-eleks-project\\\\pages\\\\_app.js\",\n                            lineNumber: 33,\n                            columnNumber: 6\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                            ...pageProps\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\Gennadii\\\\breakthrough1000-eleks-project\\\\pages\\\\_app.js\",\n                            lineNumber: 34,\n                            columnNumber: 6\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\Gennadii\\\\breakthrough1000-eleks-project\\\\pages\\\\_app.js\",\n                    lineNumber: 27,\n                    columnNumber: 5\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\Gennadii\\\\breakthrough1000-eleks-project\\\\pages\\\\_app.js\",\n            lineNumber: 22,\n            columnNumber: 4\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Gennadii\\\\breakthrough1000-eleks-project\\\\pages\\\\_app.js\",\n        lineNumber: 21,\n        columnNumber: 3\n    }, this);\n};\nMyApp.propTypes = {\n    Component: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().elementType.isRequired),\n    emotionCache: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().object),\n    pageProps: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().object.isRequired)\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQStCO0FBQ0k7QUFDTjtBQUN3QjtBQUNEO0FBQ0w7QUFDZDtBQUMwQjtBQUNBO0FBRTNELGlEQUFpRDtBQUNqRCw4QkFBOEI7QUFFOUIsTUFBTVMsc0JBQXNCLEdBQUdGLG1FQUFrQixFQUFFO0FBRXBDLFNBQVNHLEtBQUssQ0FBQ0MsS0FBSyxFQUFFO0lBQ3BDLE1BQU0sRUFBRUMsU0FBUyxHQUFFQyxZQUFZLEVBQzlCSixzQkFBc0IsR0FBRUssU0FBUyxHQUFFLEdBQUdILEtBQUs7SUFFNUMscUJBQ0MsOERBQUNILG1FQUFZO2tCQUNaLDRFQUFDSCx5REFBYTtZQUFDVSxLQUFLLEVBQUVGLFlBQVk7OzhCQUNqQyw4REFBQ1gsa0RBQUk7OEJBQ0osNEVBQUNjLE1BQUk7d0JBQUNDLElBQUksRUFBQyxVQUFVO3dCQUNwQkMsT0FBTyxFQUFDLHFDQUFxQzs7Ozs7NEJBQUc7Ozs7O3dCQUMzQzs4QkFDUCw4REFBQ2YsK0RBQWE7b0JBQUNHLEtBQUssRUFBRUEsa0RBQUs7O3NDQU0xQiw4REFBQ0Ysa0VBQVc7Ozs7Z0NBQUc7c0NBQ2YsOERBQUNRLFNBQVM7NEJBQUUsR0FBR0UsU0FBUzs7Ozs7Z0NBQUk7Ozs7Ozt3QkFDYjs7Ozs7O2dCQUNEOzs7OztZQUNGLENBQ2Q7Q0FDRjtBQUVESixLQUFLLENBQUNTLFNBQVMsR0FBRztJQUNqQlAsU0FBUyxFQUFFWCwwRUFBZ0M7SUFDM0NZLFlBQVksRUFBRVosMERBQWdCO0lBQzlCYSxTQUFTLEVBQUViLHFFQUEyQjtDQUN0QyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYnJlYWt0aHJvdWdoMTAwMC1uZXh0LW11aS8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCc7XHJcbmltcG9ydCB7IFRoZW1lUHJvdmlkZXIgfSBmcm9tICdAbXVpL21hdGVyaWFsL3N0eWxlcyc7XHJcbmltcG9ydCBDc3NCYXNlbGluZSBmcm9tICdAbXVpL21hdGVyaWFsL0Nzc0Jhc2VsaW5lJztcclxuaW1wb3J0IHsgQ2FjaGVQcm92aWRlciB9IGZyb20gJ0BlbW90aW9uL3JlYWN0JztcclxuaW1wb3J0IHRoZW1lIGZyb20gJy4uL3NyYy90aGVtZSc7XHJcbmltcG9ydCBjcmVhdGVFbW90aW9uQ2FjaGUgZnJvbSAnLi4vc3JjL2NyZWF0ZUVtb3Rpb25DYWNoZSc7XHJcbmltcG9ydCB7IFVzZXJQcm92aWRlciB9IGZyb20gJy4uL3NyYy9jb250ZXh0cy9Vc2VyQ29udGV4dCc7XHJcblxyXG4vLyBDbGllbnQtc2lkZSBjYWNoZSBzaGFyZWQgZm9yIHRoZSB3aG9sZSBzZXNzaW9uXHJcbi8vIG9mIHRoZSB1c2VyIGluIHRoZSBicm93c2VyLlxyXG5cclxuY29uc3QgY2xpZW50U2lkZUVtb3Rpb25DYWNoZSA9IGNyZWF0ZUVtb3Rpb25DYWNoZSgpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTXlBcHAocHJvcHMpIHtcclxuXHRjb25zdCB7IENvbXBvbmVudCwgZW1vdGlvbkNhY2hlID1cclxuXHRcdGNsaWVudFNpZGVFbW90aW9uQ2FjaGUsIHBhZ2VQcm9wcyB9ID0gcHJvcHM7XHJcblxyXG5cdHJldHVybiAoXHJcblx0XHQ8VXNlclByb3ZpZGVyPlxyXG5cdFx0XHQ8Q2FjaGVQcm92aWRlciB2YWx1ZT17ZW1vdGlvbkNhY2hlfT5cclxuXHRcdFx0XHQ8SGVhZD5cclxuXHRcdFx0XHRcdDxtZXRhIG5hbWU9XCJ2aWV3cG9ydFwiXHJcblx0XHRcdFx0XHRcdGNvbnRlbnQ9XCJpbml0aWFsLXNjYWxlPTEsIHdpZHRoPWRldmljZS13aWR0aFwiIC8+XHJcblx0XHRcdFx0PC9IZWFkPlxyXG5cdFx0XHRcdDxUaGVtZVByb3ZpZGVyIHRoZW1lPXt0aGVtZX0+XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHRcdHsvKiBDc3NCYXNlbGluZSBraWNrc3RhcnQgYW4gZWxlZ2FudCxcclxuXHRcdFx0XHRcdGNvbnNpc3RlbnQsIGFuZCBzaW1wbGUgYmFzZWxpbmUgdG9cclxuXHRcdFx0XHRcdGJ1aWxkIHVwb24uICovfVxyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0XHQ8Q3NzQmFzZWxpbmUgLz5cclxuXHRcdFx0XHRcdDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cclxuXHRcdFx0XHQ8L1RoZW1lUHJvdmlkZXI+XHJcblx0XHRcdDwvQ2FjaGVQcm92aWRlcj5cclxuXHRcdDwvVXNlclByb3ZpZGVyPlxyXG5cdCk7XHJcbn1cclxuXHJcbk15QXBwLnByb3BUeXBlcyA9IHtcclxuXHRDb21wb25lbnQ6IFByb3BUeXBlcy5lbGVtZW50VHlwZS5pc1JlcXVpcmVkLFxyXG5cdGVtb3Rpb25DYWNoZTogUHJvcFR5cGVzLm9iamVjdCxcclxuXHRwYWdlUHJvcHM6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZCxcclxufTtcclxuXHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIlByb3BUeXBlcyIsIkhlYWQiLCJUaGVtZVByb3ZpZGVyIiwiQ3NzQmFzZWxpbmUiLCJDYWNoZVByb3ZpZGVyIiwidGhlbWUiLCJjcmVhdGVFbW90aW9uQ2FjaGUiLCJVc2VyUHJvdmlkZXIiLCJjbGllbnRTaWRlRW1vdGlvbkNhY2hlIiwiTXlBcHAiLCJwcm9wcyIsIkNvbXBvbmVudCIsImVtb3Rpb25DYWNoZSIsInBhZ2VQcm9wcyIsInZhbHVlIiwibWV0YSIsIm5hbWUiLCJjb250ZW50IiwicHJvcFR5cGVzIiwiZWxlbWVudFR5cGUiLCJpc1JlcXVpcmVkIiwib2JqZWN0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./src/contexts/UserContext/index.jsx":
/*!********************************************!*\
  !*** ./src/contexts/UserContext/index.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"UserProvider\": () => (/* binding */ UserProvider),\n/* harmony export */   \"useUserContext\": () => (/* binding */ useUserContext)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material */ \"@mui/material\");\n/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jwt-decode */ \"jwt-decode\");\n/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nconst defaultValue = {\n    user: null,\n    setUser: ()=>{},\n    logout: ()=>{}\n};\nconst UserContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext(defaultValue);\nconst UserProvider = ({ children  })=>{\n    const { 0: user , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const { 0: allowRender , 1: setAllowRender  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    //////////////////////////////\n    function handleCallbackResponse(response) {\n        var userObject = jwt_decode__WEBPACK_IMPORTED_MODULE_3___default()(response.credential);\n        setUser(userObject);\n    }\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        /*global google */ google.accounts.id.initialize({\n            client_id: `${process.env.NEXT_PUBLIC_CLIENT_ID}.apps.googleusercontent.com`,\n            callback: handleCallbackResponse,\n            auto_select: true\n        });\n        setAllowRender(true);\n        google.accounts.id.prompt();\n    }, []);\n    if (!allowRender) {\n        return null;\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(UserContext.Provider, {\n        value: {\n            setUser,\n            user,\n            logout: ()=>{\n                setUser(null);\n                google.accounts.id.revoke();\n            }\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Gennadii\\\\breakthrough1000-eleks-project\\\\src\\\\contexts\\\\UserContext\\\\index.jsx\",\n        lineNumber: 38,\n        columnNumber: 12\n    }, undefined);\n};\nconst useUserContext = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(UserContext);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29udGV4dHMvVXNlckNvbnRleHQvaW5kZXguanN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUErRDtBQUNkO0FBQ2I7QUFFcEMsTUFBTU0sWUFBWSxHQUFHO0lBQ2pCQyxJQUFJLEVBQUUsSUFBSTtJQUNWQyxPQUFPLEVBQUUsSUFBTSxFQUFFO0lBQ2pCQyxNQUFNLEVBQUUsSUFBTSxFQUFFO0NBQ25CO0FBRUQsTUFBTUMsV0FBVyxpQkFBR1YsMERBQW1CLENBQUNNLFlBQVksQ0FBQztBQUU5QyxNQUFNTSxZQUFZLEdBQUcsQ0FBQyxFQUFDQyxRQUFRLEdBQUMsR0FBSztJQUN4QyxNQUFNLEtBQUNOLElBQUksTUFBRUMsT0FBTyxNQUFJTiwrQ0FBUSxDQUFDLElBQUksQ0FBQztJQUN0QyxNQUFNLEtBQUNZLFdBQVcsTUFBRUMsY0FBYyxNQUFJYiwrQ0FBUSxDQUFDLEtBQUssQ0FBQztJQUVyRCw4QkFBOEI7SUFDOUIsU0FBU2Msc0JBQXNCLENBQUNDLFFBQVEsRUFBRTtRQUN0QyxJQUFJQyxVQUFVLEdBQUdiLGlEQUFVLENBQUNZLFFBQVEsQ0FBQ0UsVUFBVSxDQUFDO1FBQ2hEWCxPQUFPLENBQUNVLFVBQVUsQ0FBQyxDQUFDO0tBQ3ZCO0lBRURmLGdEQUFTLENBQUMsSUFBTTtRQUNaLGtCQUFrQixDQUNsQmlCLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxFQUFFLENBQUNDLFVBQVUsQ0FBQztZQUMxQkMsU0FBUyxFQUFFLENBQUMsRUFBRUMsT0FBTyxDQUFDQyxHQUFHLENBQUNDLHFCQUFxQixDQUFDLDJCQUEyQixDQUFDO1lBQzVFQyxRQUFRLEVBQUVaLHNCQUFzQjtZQUNoQ2EsV0FBVyxFQUFFLElBQUk7U0FDcEIsQ0FBQyxDQUFDO1FBQ0hkLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNyQkssTUFBTSxDQUFDQyxRQUFRLENBQUNDLEVBQUUsQ0FBQ1EsTUFBTSxFQUFFLENBQUM7S0FDL0IsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUVQLElBQUksQ0FBQ2hCLFdBQVcsRUFBRTtRQUNkLE9BQU8sSUFBSTtLQUNkO0lBRUQscUJBQU8sOERBQUNKLFdBQVcsQ0FBQ3FCLFFBQVE7UUFBQ0MsS0FBSyxFQUFFO1lBQ2hDeEIsT0FBTztZQUNQRCxJQUFJO1lBQ0pFLE1BQU0sRUFBRSxJQUFNO2dCQUNWRCxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2RZLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxFQUFFLENBQUNXLE1BQU0sRUFBRSxDQUFDO2FBQy9CO1NBQ0o7a0JBQ0lwQixRQUFROzs7OztpQkFDVTtDQUMxQjtBQUVNLE1BQU1xQixjQUFjLEdBQUcsSUFBTWpDLGlEQUFVLENBQUNTLFdBQVcsQ0FBQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYnJlYWt0aHJvdWdoMTAwMC1uZXh0LW11aS8uL3NyYy9jb250ZXh0cy9Vc2VyQ29udGV4dC9pbmRleC5qc3g/YzA1MCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2lyY3VsYXJQcm9ncmVzcyB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgand0X2RlY29kZSBmcm9tIFwiand0LWRlY29kZVwiO1xyXG5cclxuY29uc3QgZGVmYXVsdFZhbHVlID0ge1xyXG4gICAgdXNlcjogbnVsbCxcclxuICAgIHNldFVzZXI6ICgpID0+IHt9LFxyXG4gICAgbG9nb3V0OiAoKSA9PiB7fSxcclxufVxyXG5cclxuY29uc3QgVXNlckNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KGRlZmF1bHRWYWx1ZSk7XHJcblxyXG5leHBvcnQgY29uc3QgVXNlclByb3ZpZGVyID0gKHtjaGlsZHJlbn0pID0+IHtcclxuICAgIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW2FsbG93UmVuZGVyLCBzZXRBbGxvd1JlbmRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBmdW5jdGlvbiBoYW5kbGVDYWxsYmFja1Jlc3BvbnNlKHJlc3BvbnNlKSB7XHJcbiAgICAgICAgdmFyIHVzZXJPYmplY3QgPSBqd3RfZGVjb2RlKHJlc3BvbnNlLmNyZWRlbnRpYWwpO1xyXG4gICAgICAgIHNldFVzZXIodXNlck9iamVjdCk7XHJcbiAgICB9XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICAvKmdsb2JhbCBnb29nbGUgKi9cclxuICAgICAgICBnb29nbGUuYWNjb3VudHMuaWQuaW5pdGlhbGl6ZSh7XHJcbiAgICAgICAgICAgIGNsaWVudF9pZDogYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQ0xJRU5UX0lEfS5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbWAsXHJcbiAgICAgICAgICAgIGNhbGxiYWNrOiBoYW5kbGVDYWxsYmFja1Jlc3BvbnNlLFxyXG4gICAgICAgICAgICBhdXRvX3NlbGVjdDogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRBbGxvd1JlbmRlcih0cnVlKTtcclxuICAgICAgICBnb29nbGUuYWNjb3VudHMuaWQucHJvbXB0KCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgaWYgKCFhbGxvd1JlbmRlcikge1xyXG4gICAgICAgIHJldHVybiBudWxsXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIDxVc2VyQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17e1xyXG4gICAgICAgIHNldFVzZXIsXHJcbiAgICAgICAgdXNlcixcclxuICAgICAgICBsb2dvdXQ6ICgpID0+IHtcclxuICAgICAgICAgICAgc2V0VXNlcihudWxsKTtcclxuICAgICAgICAgICAgZ29vZ2xlLmFjY291bnRzLmlkLnJldm9rZSgpO1xyXG4gICAgICAgIH0sXHJcbiAgICB9fT5cclxuICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L1VzZXJDb250ZXh0LlByb3ZpZGVyPlxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgdXNlVXNlckNvbnRleHQgPSAoKSA9PiB1c2VDb250ZXh0KFVzZXJDb250ZXh0KTtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlQ29udGV4dCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiQ2lyY3VsYXJQcm9ncmVzcyIsImp3dF9kZWNvZGUiLCJkZWZhdWx0VmFsdWUiLCJ1c2VyIiwic2V0VXNlciIsImxvZ291dCIsIlVzZXJDb250ZXh0IiwiY3JlYXRlQ29udGV4dCIsIlVzZXJQcm92aWRlciIsImNoaWxkcmVuIiwiYWxsb3dSZW5kZXIiLCJzZXRBbGxvd1JlbmRlciIsImhhbmRsZUNhbGxiYWNrUmVzcG9uc2UiLCJyZXNwb25zZSIsInVzZXJPYmplY3QiLCJjcmVkZW50aWFsIiwiZ29vZ2xlIiwiYWNjb3VudHMiLCJpZCIsImluaXRpYWxpemUiLCJjbGllbnRfaWQiLCJwcm9jZXNzIiwiZW52IiwiTkVYVF9QVUJMSUNfQ0xJRU5UX0lEIiwiY2FsbGJhY2siLCJhdXRvX3NlbGVjdCIsInByb21wdCIsIlByb3ZpZGVyIiwidmFsdWUiLCJyZXZva2UiLCJ1c2VVc2VyQ29udGV4dCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/contexts/UserContext/index.jsx\n");

/***/ }),

/***/ "./src/createEmotionCache.js":
/*!***********************************!*\
  !*** ./src/createEmotionCache.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ createEmotionCache)\n/* harmony export */ });\n/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/cache */ \"@emotion/cache\");\n/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_cache__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction createEmotionCache() {\n    return _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default()({\n        key: \"css\",\n        prepend: true\n    });\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY3JlYXRlRW1vdGlvbkNhY2hlLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUF5QztBQUUxQixTQUFTQyxrQkFBa0IsR0FBRztJQUM1QyxPQUFPRCxxREFBVyxDQUFDO1FBQUVFLEdBQUcsRUFBRSxLQUFLO1FBQUVDLE9BQU8sRUFBRSxJQUFJO0tBQUUsQ0FBQyxDQUFDO0NBQ2xEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYnJlYWt0aHJvdWdoMTAwMC1uZXh0LW11aS8uL3NyYy9jcmVhdGVFbW90aW9uQ2FjaGUuanM/Y2MyMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgY3JlYXRlQ2FjaGUgZnJvbSAnQGVtb3Rpb24vY2FjaGUnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY3JlYXRlRW1vdGlvbkNhY2hlKCkge1xyXG5cdHJldHVybiBjcmVhdGVDYWNoZSh7IGtleTogJ2NzcycsIHByZXBlbmQ6IHRydWUgfSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbImNyZWF0ZUNhY2hlIiwiY3JlYXRlRW1vdGlvbkNhY2hlIiwia2V5IiwicHJlcGVuZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/createEmotionCache.js\n");

/***/ }),

/***/ "./src/theme.js":
/*!**********************!*\
  !*** ./src/theme.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/material/styles */ \"@mui/material/styles\");\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material/colors */ \"@mui/material/colors\");\n/* harmony import */ var _mui_material_colors__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_colors__WEBPACK_IMPORTED_MODULE_1__);\n\n\n// Create a theme instance.\nconst theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.createTheme)({\n    palette: {\n        primary: {\n            main: \"#556cd6\"\n        },\n        secondary: {\n            main: \"#19857b\"\n        },\n        error: {\n            main: _mui_material_colors__WEBPACK_IMPORTED_MODULE_1__.red.A400\n        }\n    }\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (theme);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvdGhlbWUuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBbUQ7QUFDUjtBQUUzQywyQkFBMkI7QUFDM0IsTUFBTUUsS0FBSyxHQUFHRixpRUFBVyxDQUFDO0lBQ3pCRyxPQUFPLEVBQUU7UUFDUkMsT0FBTyxFQUFFO1lBQ1JDLElBQUksRUFBRSxTQUFTO1NBQ2Y7UUFDREMsU0FBUyxFQUFFO1lBQ1ZELElBQUksRUFBRSxTQUFTO1NBQ2Y7UUFDREUsS0FBSyxFQUFFO1lBQ05GLElBQUksRUFBRUosMERBQVE7U0FDZDtLQUNEO0NBQ0QsQ0FBQztBQUVGLGlFQUFlQyxLQUFLLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9icmVha3Rocm91Z2gxMDAwLW5leHQtbXVpLy4vc3JjL3RoZW1lLmpzP2FmYTQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlVGhlbWUgfSBmcm9tICdAbXVpL21hdGVyaWFsL3N0eWxlcyc7XHJcbmltcG9ydCB7IHJlZCB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwvY29sb3JzJztcclxuXHJcbi8vIENyZWF0ZSBhIHRoZW1lIGluc3RhbmNlLlxyXG5jb25zdCB0aGVtZSA9IGNyZWF0ZVRoZW1lKHtcclxuXHRwYWxldHRlOiB7XHJcblx0XHRwcmltYXJ5OiB7XHJcblx0XHRcdG1haW46ICcjNTU2Y2Q2JyxcclxuXHRcdH0sXHJcblx0XHRzZWNvbmRhcnk6IHtcclxuXHRcdFx0bWFpbjogJyMxOTg1N2InLFxyXG5cdFx0fSxcclxuXHRcdGVycm9yOiB7XHJcblx0XHRcdG1haW46IHJlZC5BNDAwLFxyXG5cdFx0fSxcclxuXHR9LFxyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHRoZW1lO1xyXG4iXSwibmFtZXMiOlsiY3JlYXRlVGhlbWUiLCJyZWQiLCJ0aGVtZSIsInBhbGV0dGUiLCJwcmltYXJ5IiwibWFpbiIsInNlY29uZGFyeSIsImVycm9yIiwiQTQwMCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/theme.js\n");

/***/ }),

/***/ "@emotion/cache":
/*!*********************************!*\
  !*** external "@emotion/cache" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@emotion/cache");

/***/ }),

/***/ "@emotion/react":
/*!*********************************!*\
  !*** external "@emotion/react" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@emotion/react");

/***/ }),

/***/ "@mui/material":
/*!********************************!*\
  !*** external "@mui/material" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ "@mui/material/CssBaseline":
/*!********************************************!*\
  !*** external "@mui/material/CssBaseline" ***!
  \********************************************/
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ "@mui/material/colors":
/*!***************************************!*\
  !*** external "@mui/material/colors" ***!
  \***************************************/
/***/ ((module) => {

module.exports = require("@mui/material/colors");

/***/ }),

/***/ "@mui/material/styles":
/*!***************************************!*\
  !*** external "@mui/material/styles" ***!
  \***************************************/
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ "jwt-decode":
/*!*****************************!*\
  !*** external "jwt-decode" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();