import React from 'react'
import styles from "../styles/users.module.scss";
import Kardio from '../public/Pulse2.gif';
import Image from "next/image";


export const Minuts = ({ onChange }) => {
  const handleNumber1Change = (event) => {
    onChange(event.target.value)
  }
  
  const handleNumber2Change = (event) => {
    onChange(event.target.value)
  }

  const handleNumber3Change = (event) => {
    onChange(event.target.value)
  }

  const handleNumber4Change = (event) => {
    onChange(event.target.value)
  }

  return (
    <div className={styles.buttonTime}>
      <div className={styles.lForm}>
        <div className={styles.form__div1}>
          <input type="number" className={styles.form__input} placeholder="min" onChange={handleNumber1Change} />
          <label for="" className={styles.form__label}>TIME</label>
        </div>
        <div className={styles.form__div2}>
          <input type="number" className={styles.form__input} placeholder="min" onChange={handleNumber2Change} />
          <label for="" className={styles.form__label}>TIME</label>
        </div>
        <div className={styles.form__div3}>
          <input type="number" className={styles.form__input} placeholder="min" onChange={handleNumber3Change} />
          <label for="" className={styles.form__label}>TIME</label>
        </div>
        <div className={styles.form__div4}>
          <input type="number" className={styles.form__input} placeholder="min" onChange={handleNumber4Change} />
          <label for="" className={styles.form__label}>TIME</label>
        </div>
      </div>
      <div className={styles.kardio}>
        <Image src={Kardio}  alt="kardio"/>
      </div> 
    </div>
   
  )
}

export default Minuts;