// import React from 'react'
// import { useState } from 'react'
// import Minuts from './timer'
// import styles from "../styles/users.module.scss";

// export const Burn = () => {
//   const [number, setNumber] = useState('')

//   const handleNumberChange = (number) => {
//     setNumber(number)
//   }

//   return (
//     <div className={styles.lForm2}>
//       <div className={styles.form2__div1}>
//           <input type="date" className={styles.form2__input} placeholder=" " />
//           <label for="" className={styles.form2__label}>DATE</label>
//       </div>
//       <div className={styles.form2__div2}>
//           <input type="text" className={styles.form2__input} placeholder="KG" />
//           <label for="" className={styles.form2__label}>BODY WEIGHT</label>
//       </div>
//       <div className={styles.form2__div3}>
//           <input type="text" className={styles.form2__input} placeholder="1000" >
//            {number} </input>
//           <label for="" className={styles.form2__label}>  KCAL BURNED TODAY</label>
//       </div>
//       <Minuts onChange={handleNumberChange} />
//     </div> 
//   )
// }

// export default Burn;