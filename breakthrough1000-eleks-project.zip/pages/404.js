export default function Error() {
  return (
    <h1>
      МОЯ КАСТОМНА СТОРІНКА З ПОМИЛКОЮ
    </h1>
  )
};