import styles from "../styles/users.module.scss";
import Stack from '@mui/material/Stack';
import Image from "next/image";
import Pulse from '../public/Pulse.png';
import Timer from '../public/Timer.png';
import Avatar from '@mui/material/Avatar';
import Gennadii from '../public/Gennadii.jpg';
import Minuts from './timer';
import { useState } from 'react'


import React from 'react'

export default function DairyCard() {
  const [number1, setNumber1] = useState('')
  const [number2, setNumber2] = useState('')
  const [number3, setNumber3] = useState('')
  const [number4, setNumber4] = useState('')

  const handleNumber1Change = (number1) => {
    setNumber1(number1)

  }

  const handleNumber2Change = (number2) => {
    setNumber2(number2)
  }

  const handleNumber3Change = (number3) => {
    setNumber3(number3)
  }
      
  const handleNumber4Change = (number4) => {
    setNumber4(number4)
  }

  let sum = 1000;
  
  sum += +number1 * 7.5 + +number2 * 10 +number3 * 12.5 +number4 * 15;
  
  
  return (
    <div className={styles.userContainer}>
            <div className={styles.name}>
              USER NAME
            </div>
            <div>
              <Stack direction="row" spacing={2}>
                <Avatar className={styles.photo} alt="User" src={Gennadii} />
              </Stack>
            </div>  
            <div className={styles.diary}>
              <div className={styles.pulse}>
                <Image src={Pulse}  alt="pulse"/>
              </div>
              <div className={styles.timer}>
                <Image src={Timer}  alt="timer"/>
              </div>
              <div className={styles.lForm2}>
                <div className={styles.form2__div1}>
                    <input type="date" className={styles.form2__input} placeholder=" " />
                    <label for="" className={styles.form2__label}>DATE</label>
                </div>
                <div className={styles.form2__div2}>
                    <input type="text" className={styles.form2__input} placeholder="KG" />
                    <label for="" className={styles.form2__label}>BODY WEIGHT</label>
                </div>
                <div className={styles.form2__div3}>
                    <input type="text" className={styles.form2__input} placeholder=" "  value={sum}>
                     </input>
                    <label for="" className={styles.form2__label}>  KCAL BURNED TODAY</label>
                </div> 
              </div> 
              <div className={styles.buttonZone}>
                <button className={styles.button}>100-120</button>    
                <button className={styles.button}>120-140</button>
                <button className={styles.button}>140-160</button>
                <button className={styles.button}>160-180</button>
              </div>   
              <Minuts onChange={handleNumber1Change} />
              <Minuts onChange={handleNumber2Change} />
              <Minuts onChange={handleNumber3Change} />
              <Minuts onChange={handleNumber4Change} />              
            </div>
          </div>
  )
}



